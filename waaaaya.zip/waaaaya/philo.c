/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   philo.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mmaghri <mmaghri@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/26 03:38:54 by mmaghri           #+#    #+#             */
/*   Updated: 2024/05/04 16:02:13 by mmaghri          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philo.h"
#include <string.h>

void	this_init(t_in_str *this, t_ini	*copy)
{
	copy->nmp = this->nmp;
	copy->start_time = fu();
	copy->each_time = 0;
	copy->nf_t_each_philo = this->nf_t_each_philo ;
	copy->lock_each_time = &this->lock_each_time;
	copy->monitor = &this->monitor;
	copy->thisthread = &this->thisthread;
	copy->lock_it_up = &this->lock_it_up;
	copy->lock_him = &this->lock_him;
	copy->this = &this->this;
	copy->ix = 0;
}

t_ini	*start_dining(t_in_str *this)
{
	t_ini	*copy;

	copy = malloc(sizeof(t_ini) * this->nmp);
	if (!copy)
		return (NULL);
	while (copy->ix < this->nmp)
	{
		copy[copy->ix].id = copy->ix + 1;
		copy[copy->ix].whole_philos = this->nmp;
		copy[copy->ix].left_one = (copy->ix + 1) % this->nmp;
		copy[copy->ix].right_one = copy->ix;
		copy[copy->ix].lock_var = &this->lock_var[copy[copy->ix].left_one];
		copy[copy->ix].sec_var = &this->lock_var[copy[copy->ix].right_one];
		copy[copy->ix].time_to_sleep = this->time_to_sleep;
		copy[copy->ix].print_not = &this->print_not;
		copy[copy->ix].print_not = &this->print_not;
		copy[copy->ix].time_to_eat = this->time_to_eat;
		copy[copy->ix].time_to_die = this->time_to_die;
		copy[copy->ix].onlyone = &this->only_one;
		copy[copy->ix].stop = &this->stop;
		this_init(this, &copy[copy->ix]);
		copy->ix++ ;
	}
	copy->ix = 0;
	return (copy);
}

void	mute_it(t_ini *waa)
{
	pthread_mutex_lock(waa->lock_each_time);
	waa->each_time++;
	pthread_mutex_unlock(waa->lock_each_time);
}

void	lock_print(t_ini *waa)
{
	f_p("is sleeping\n", waa->id, (fu() - waa->start_time), waa);
	function_sleep(waa->time_to_sleep);
	f_p("is thinking\n", waa->id, (fu() - waa->start_time), waa);
	pthread_mutex_lock(waa->stop);
	pthread_mutex_unlock(waa->stop);
}

void	*start_philos(void *args)
{
	t_ini	*waa;

	waa = (t_ini *)args;
	if (waa->id % 2 == 0)
		usleep(500);
	while (1)
	{
		pthread_mutex_lock(waa->lock_var);
		f_p("has taken a fork\n", waa->id, (fu() - waa->start_time), waa);
		if (waa->nmp == 1)
			pthread_mutex_lock(waa->lock_var);
		pthread_mutex_lock(waa->sec_var);
		f_p("has taken a fork\n", waa->id, (fu() - waa->start_time), waa);
		pthread_mutex_lock(waa->lock_him);
		waa->last_meal_time = fu();
		pthread_mutex_unlock(waa->lock_him);
		mute_it(waa);
		f_p("is eating\n", waa->id, (fu() - waa->start_time), waa);
		function_sleep(waa->time_to_eat);
		pthread_mutex_unlock(waa->lock_var);
		pthread_mutex_unlock(waa->sec_var);
		lock_print(waa);
	}
	return (NULL);
}
