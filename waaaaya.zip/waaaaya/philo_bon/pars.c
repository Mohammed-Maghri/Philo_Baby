/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   pars.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mmaghri <mmaghri@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/04/23 17:04:02 by mmaghri           #+#    #+#             */
/*   Updated: 2024/05/04 15:02:46 by mmaghri          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "phil.h"

int	check_pars(char pars)
{
	if (pars >= '0' && pars <= '9')
		return (0);
	return (-1);
}

int	check_if(char **all_this, int argc)
{
	int		index;

	index = 1;
	while (all_this[index])
	{
		if (loop_on_all(all_this[index], argc) == -1)
			return (-1);
		index++;
	}
	return (0);
}

void	only_this(t_not *copy)
{
	pthread_create(&copy->initial, NULL, &start_philos, copy);
	pthread_detach(copy->initial);
}

int	*return_to_array(char **argv)
{
	int		index;
	int		*this_array;
	int		increment;

	increment = 0;
	this_array = malloc(sizeof(int) * 5);
	if (!this_array)
		return (NULL);
	index = 1;
	while (argv[index])
	{
		if (number_converter(argv[index]) == -1)
			return (printf("Invalid argument !\n"), NULL);
		this_array[increment] = check_valid(argv[index]);
		increment++;
		index++;
	}
	return (this_array);
}
