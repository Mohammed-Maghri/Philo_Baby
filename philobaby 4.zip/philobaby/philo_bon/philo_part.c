/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   philo_part.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mmaghri <mmaghri@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/04/24 11:12:21 by mmaghri           #+#    #+#             */
/*   Updated: 2024/04/26 16:34:46 by mmaghri          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "phil.h"

long long	fu(void)
{
	struct timeval	this_time;

	gettimeofday(&this_time, NULL);
	return (this_time.tv_sec * 1000 + this_time.tv_usec / 1000);
}

void phill_vars_nedded(t_not *phill, int *array)
{
    phill->number_philos = array[0];
    phill->time_die = array[1];
    phill->time_sleep = array[3];
    phill->time_eat = array[2];
    if (array[4] == 0)
        phill->each_philo = -1;
    else
        phill->each_philo = array[4];
}
void	f_p(char *string, int id, long long pass, sem_t *var)
{
    sem_wait(var);
	printf("%lld %d %s", pass, id, string);
    sem_post(var);
}
void *start_philos(void *args)
{
    t_not *check;
    check = (t_not*)args;

    while (1)
    {
        check->outside = check->outside + 1;
        usleep(500);
        if ((fu() - check->last_meal_time) > check->time_die)
        {
            exit(1);
        }
    }
    return (NULL);
}

t_not   *return_number_philo(t_not *check)
{
    int		index;
	t_not	*this = malloc(sizeof(t_not) * check->number_philos);

	index = 0;
    while (index < check->number_philos)
    {
		this[index].number_philos = check->number_philos ;
		this[index].each_philo = check->each_philo ;
		this[index].time_die = check->time_die ;
		this[index].time_eat = check->time_eat ;
		this[index].time_sleep = check->time_sleep ;
		this[index].how_many_time = check->how_many_time ;
		this[index].last_meal_time = 0;
		this[index].id = index ;
		this[index].outside = 0;
		index++ ;
    }
	return (this);
}


void	function_sleep(long long in_milisecond)
{
	long long		start;

	(void)in_milisecond;
	start = fu();
	while (fu() - start < in_milisecond)
		usleep(50);
}

void    make_bonus(t_this *varible, t_not *check)
{
    (void)varible ;
    int index;
    pid_t pid;

    pid = -1;
    index = 0;
	t_not *copy;
    int *value ;
    int flag;

    flag = 0;
    value = &index;
	copy = return_number_philo(check);
    sem_unlink("semp");
    copy->var = sem_open("semp", O_CREAT | S_IWUSR, 1);
    while (index < copy[index].number_philos)
    {
        pid = fork();
        copy[index].porcess[index] = pid;
        copy->start_time = fu() ;
        if (pid == 0)
        {
            while (1)
            {
                // pthread_create(&copy[index].initial, NULL, &start_philos, &copy[index]);
                sem_wait(copy->var);
                copy[index].last_meal_time = fu();
                f_p("Has taken a fork\n", copy[index].id, (fu() - copy->start_time), copy->var);
                f_p("Has taken a fork\n", copy[index].id, (fu() - copy->start_time), copy->var);
                f_p("is eating\n", copy[index].id, (fu() - copy->start_time), copy->var);
                function_sleep(copy[index].time_eat);
                f_p("is sleeping\n", copy[index].id, (fu() - copy->start_time), copy->var);
                function_sleep(copy[index].time_sleep); 
                sem_post(copy->var);
                // pthread_join(copy[index].initial, NULL);            
            }
        }
        printf("\n");
        index++;
    }
    while (wait(NULL) != -1)
    ;
    // while (index < copy[index].number_philos)
    // {
    //     printf(" %d ", index);
    //     printf("******| %d |******\n", copy[index].porcess[index]);
    //     waitpid(copy[index].porcess[index], NULL , 0);
    //     index++ ;
    // }
}   