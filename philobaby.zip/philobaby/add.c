/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   add.c                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mmaghri <mmaghri@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/04/20 16:06:22 by mmaghri           #+#    #+#             */
/*   Updated: 2024/04/20 20:29:34 by mmaghri          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philo.h"

int	put_in(int argc, t_in_str *this, int *array)
{
	if (argc - 1 == 4)
		this->nf_t_each_philo = -1;
	else if (argc - 1 == 5)
		this->nf_t_each_philo = array[4];
	this->number_of_philosophers = array[0];
	this->time_to_die = array[1];
	this->time_to_eat = array[2];
	this->time_to_sleep = array[3];
	if (this->nf_t_each_philo == 0)
	{
		printf("Not Enough !\n");
		return (-1);
	}
	return (1);
}

int	fill_shit(t_in_str *this, int *array, int argc)
{
	int		index;
	int		res;

	(void)this;
	(void)array;
	res = put_in(argc, this, array);
	if (res == -1)
		return (-1);
	index = 0;
	while (index < this->number_of_philosophers)
	{
		pthread_mutex_init(&this->lock_var[index], NULL);
		index++;
	}
	pthread_mutex_init(&this->lock_up, NULL);
	pthread_mutex_init(&this->print_not, NULL);
	pthread_mutex_init(&this->monitor, NULL);
	pthread_mutex_init(&this->only_one, NULL);
	pthread_mutex_init(&this->stop, NULL);
	pthread_mutex_init(&this->lock_it_up, NULL);
	return (0);
}

void	incre_this(t_ini *point, int *flag, int *increment)
{
	if (point->each_time == point->nf_t_each_philo)
	{
		*flag += 1 ;
		*increment += 1;
	}
}
