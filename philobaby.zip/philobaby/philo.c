/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   philo.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mmaghri <mmaghri@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/26 03:38:54 by mmaghri           #+#    #+#             */
/*   Updated: 2024/04/14 11:49:15 by mmaghri          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philo.h"

int check_if(char **all_this, int argc)
{
    int index;

    index = 1;
    while (all_this[index])
    {
        if (loop_on_all(all_this[index], argc) == -1)
            return (-1);
        index++ ;
    }
    return (0);
}
int *return_to_array(char **argv)
{
    int     index;
    int    *this_array;
    int     increment;

    increment = 0;
    this_array = malloc(sizeof(int) * 5);
    if (!this_array)
        return (NULL);
    index = 1;
    while (argv[index])
    {
        if (number_converter(argv[index]) == -1)
        {
            printf("Invalid argument !\n");
            return (NULL);
        }
        this_array[increment] = check_valid(argv[index]);
        increment++ ;
        index++ ;
    }
    return (this_array);
}

int fill_shit(in_str *this, int *array, int argc)
{
    (void)this;
    (void)array;

    if (argc - 1  == 4)
        this->nf_t_each_philo = -1;
    else if (argc -1 == 5)
        this->nf_t_each_philo = array[4];
    this->number_of_philosophers = array[0];
    this->time_to_die = array[1];
    this->time_to_eat = array[2];
    this->time_to_sleep = array[3];
    if (this->nf_t_each_philo == 0)
    {
        printf("Not Enough !\n");
        return(-1);
    }
    return (0);
}

t_ini *start_dining(in_str *this)
{
    t_this wee;

    wee.index = 0;
    t_ini *copy;

    copy = this->philo;
    copy = malloc(sizeof(t_ini) * this->number_of_philosophers);
    while (wee.index < this->number_of_philosophers)
    {
        copy[wee.index].id = wee.index + 1;
        copy[wee.index].whole_philos = this->number_of_philosophers;
        copy[wee.index].left_one = wee.index;
        copy[wee.index].right_one = (wee.index + 1) % this->number_of_philosophers;
        pthread_mutex_init(&copy[wee.index].lock_var, NULL);
        wee.index++ ;
    }
    wee.index = 0;
    return (copy);
}

void *start_philos(void *args)
{
   t_ini *waa;
    int index;

    index = 0;
    waa = (t_ini *)args ;
    pthread_mutex_lock(&waa->lock_var);

    printf("\n------------------------------\n");
    printf("    |%d|    ", waa->id);
    printf("---> [%d] ", waa->left_one);
    printf("--->( %d ) ", waa->right_one);
    printf("---> * %d * ", waa->whole_philos);
    printf("\n----------\n\n\n");
    pthread_mutex_unlock(&waa->lock_var);
    return (NULL);
}

void function_create_many_philos(t_ini *point, in_str *more)
{
    pthread_t this_thread;
    int index;

    index = 0;

    while (index < more->number_of_philosophers)
    {
        pthread_create(&this_thread, NULL, &start_philos, &point[index]);
        pthread_detach(this_thread);
        printf("|%d|\n\n", index);
        index++ ;
    }
    index = 0;
    while (index < more->number_of_philosophers)
    {
        index++ ;
    }
}

int main(int argc, char **argv)
{
    if (argc > 6)
    {
        printf("Invalid Argument !\n");
        return (0);
    }
    int index ;
    int *all_of_it;
    t_ini *waa;

    index = 1;
    if (check_if(argv, argc) == -1)
        return (-1);
    all_of_it = return_to_array(argv);
    if (!all_of_it)
        return (0);
    in_str  *this_all;
    this_all = malloc(sizeof(in_str));
    if (fill_shit(this_all , all_of_it, argc) == -1)
        return (-1);
    waa = start_dining(this_all);
    function_create_many_philos(waa, this_all);
    return 0;
}
