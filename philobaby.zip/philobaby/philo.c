/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   philo.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mmaghri <mmaghri@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/26 03:38:54 by mmaghri           #+#    #+#             */
/*   Updated: 2024/04/20 20:29:26 by mmaghri          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philo.h"

void	dining_func(t_in_str *this, t_ini	*copy)
{
	copy->onlyone = &this->only_one;
	copy->stop = &this->stop;
	copy->lock_up = &this->lock_up;
	copy->nf_t_each_philo = this->nf_t_each_philo;
	copy->number_of_philosophers = this->number_of_philosophers;
	copy->start_time = function_count_mils();
}

t_ini	*start_dining(t_in_str *this)
{
	t_this	wee;
	t_ini	*copy;

	wee.index = 0;
	copy = malloc(sizeof(t_ini) * this->number_of_philosophers);
	while (wee.index < this->number_of_philosophers)
	{
		copy[wee.index].id = wee.index + 1;
		copy[wee.index].whole_philos = this->number_of_philosophers;
		copy[wee.index].right_one = (wee.index + 1) % \
		this->number_of_philosophers;
		copy[wee.index].left_one = wee.index;
		copy[wee.index].lock_var = &this->lock_var[copy[wee.index].left_one];
		copy[wee.index].sec_var = &this->lock_var[copy[wee.index].right_one];
		copy[wee.index].time_to_sleep = this->time_to_sleep;
		copy[wee.index].print_not = &this->print_not;
		copy[wee.index].time_to_eat = this->time_to_eat;
		copy[wee.index].time_to_die = this->time_to_die;
		copy[wee.index].lock_it_up = &this->lock_it_up;
		dining_func(this, &copy[wee.index]);
		wee.index++;
	}
	wee.index = 0;
	return (copy);
}

void	help_start(t_ini	*waa, int check)
{
	if (check == -1)
	{
		pthread_mutex_lock(waa->lock_up);
		waa->each_time++;
		pthread_mutex_unlock(waa->lock_up);
	}
	if (check == 0)
	{
		if (waa->id % 2 == 0)
			usleep(500);
	}
}

void	*start_philos(void *args)
{
	t_ini	*waa;

	waa = (t_ini *)args;
	help_start(waa, 0);
	while (1)
	{
		pthread_mutex_lock(waa->lock_var);
		function_p("has taken a fork\n", waa->id, (function_count_mils() - \
		waa->start_time), waa);
		pthread_mutex_lock(waa->sec_var);
		function_p("has taken a fork\n", waa->id, (function_count_mils() - \
		waa->start_time), waa);
		pthread_mutex_lock(waa->lock_it_up);
		waa->last_meal_time = function_count_mils();
		pthread_mutex_unlock(waa->lock_it_up);
		help_start(waa, -1);
		function_p("is eating\n", waa->id, (function_count_mils() - \
		waa->start_time), waa);
		function_sleep(waa->time_to_eat);
		pthread_mutex_unlock(waa->lock_var);
		pthread_mutex_unlock(waa->sec_var);
		function_p("is sleeping\n", waa->id, (function_count_mils() - \
		waa->start_time), waa);
		function_sleep(waa->time_to_sleep);
	}
	return (NULL);
}

void	function_add(t_ini *point, int index, int flag, int increment)
{
	while (1)
	{
		pthread_mutex_lock(point->lock_it_up);
		incre_this(point, &flag, &increment);
		if (increment == point[increment].number_of_philosophers - 1 \
		&& flag == point[increment].number_of_philosophers - 1)
			break ;
		usleep(50);
		if (index == point->number_of_philosophers)
			index = 0;
		if ((function_count_mils() - point->last_meal_time) > \
		point[index].time_to_die)
		{
			function_t(point);
			function_p("died\n", point->id, (function_count_mils() - \
			point->start_time), point);
			pthread_mutex_lock(point->print_not);
			index = -1;
			break ;
		}
		pthread_mutex_unlock(point->lock_it_up);
		index++ ;
	}
}
