/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mmaghri <mmaghri@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/04/20 15:50:08 by mmaghri           #+#    #+#             */
/*   Updated: 2024/04/20 17:03:15 by mmaghri          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philo.h"

void	function_create_many_philos(t_ini *point, t_in_str *more)
{
	t_this	t;

	t.flag = 0;
	t.increment = 0;
	t.index = 0;
	while (t.index < more->number_of_philosophers)
	{
		point[t.index].last_meal_time = function_count_mils();
		pthread_create(&t.this_thread, NULL, &start_philos, &point[t.index]);
		pthread_detach(t.this_thread);
		t.index++;
	}
	t.index = 0;
	function_add(point, t.index, t.flag, t.increment);
	if (t.index == -1)
		return ;
}

void	function_sleep(long long in_milisecond)
{
	long long	start;

	(void)in_milisecond;
	start = function_count_mils();
	while (function_count_mils() - start < in_milisecond)
		usleep(50);
}

long long	function_count_mils(void)
{
	struct timeval	this_time;

	gettimeofday(&this_time, NULL);
	return (this_time.tv_sec * 1000 + this_time.tv_usec / 1000);
}

int	main(int argc, char **argv)
{
	int			index;
	int			*all_of_it;
	t_ini		*waa;
	t_in_str	*this_all;

	if (argc > 6)
	{
		printf("Invalid Argument !\n");
		return (0);
	}
	index = 1;
	if (check_if(argv, argc) == -1)
		return (-1);
	all_of_it = return_to_array(argv);
	if (!all_of_it)
		return (0);
	this_all = malloc(sizeof(t_in_str));
	if (fill_shit(this_all, all_of_it, argc) == -1)
		return (-1);
	waa = start_dining(this_all);
	function_create_many_philos(waa, this_all);
	return (0);
}
