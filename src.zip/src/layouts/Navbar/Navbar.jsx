import "../../pages/Home/Home.css"
import { GiShoppingCart } from "react-icons/gi";
import { FaRegHeart } from "react-icons/fa";
import { CiUser } from "react-icons/ci";
import { CiSearch } from "react-icons/ci";
import { RiArrowDownSLine } from "react-icons/ri";
import { TbBrandBluesky } from "react-icons/tb";
import { Link } from 'react-router-dom';
import React, { useEffect } from 'react';

function Navbar() {

    let declare;
    let out_this;
    let for_textures;
    let text_it;

    useEffect(() => {
        declare = document.getElementById('in-down');
    }, []);
    function dlet_this() {
        console.log('herer');
        console.log(declare.innerHTML);
        if (declare.style.display == 'none')
            declare.style.display = 'block';
        else
            declare.style.display = 'none';
        };
    return (
        <div className='nav-bar'>
            <div className='slider-logo'></div>
            <div className='for-logo'>
                <div className='each'>
                    <p> Women </p>
                </div>
                <div className='each'>
                    <p>  Men </p>
                </div>
                <div className='each'>
                    <p> Brands </p>
                </div>
                <div className='each'>
                    <p> Children </p>
                </div>
            </div>
            <div className='for-types'>
                <TbBrandBluesky />
                <Link to={"/"}><p className='name'> ButterflyesFusion </p></Link>
            </div>
            <div className='for-client'>
                <div className='out-side'>
                    <div className='langtwo'>

                    </div>
                    <div onClick={dlet_this} className='lang'>
                        <div   id='in-down' className='dragit'>
                            <p> English </p>
                            <p> French </p>
                            <p> Arabic </p>
                        </div>
                        <div className='out'>
                            <p> En </p>
                            <RiArrowDownSLine  className='drag' id='drag-this' />
                        </div>
                        <div className='in'>
                            <p> MAD </p>
                        </div>
                    </div>
                </div>
                <div className='in-side'>
                    <div className='icons'>
                        <CiSearch className='elem-icons' />
                    </div>
                    <div className='icons'>
                        <FaRegHeart className='wich-list-icon' />
                    </div>
                    <div className='icons'>
                        <GiShoppingCart className='elem-icons' />
                    </div>
                    <div className='icons'>
                        <Link to="/Admin"><CiUser className='elem-icons' /></Link>
                    </div>
                </div>
            </div>
            <div className='slider-client'></div>
        </div>
    );
}
export default Navbar;