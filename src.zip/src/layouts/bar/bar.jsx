import "../../pages/Home/Home.css"
import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { TbBrandBluesky } from "react-icons/tb";
import { TfiHelpAlt } from "react-icons/tfi";
import { CiDeliveryTruck } from "react-icons/ci";
import { BsCalendar4Week } from "react-icons/bs";

function Bar() {
    return (
        <div className='down-her'>
                <div className='divall'>
                    <div className='boxes'>
                        <TbBrandBluesky className='ico' />
                        <div className='elemico'>
                            <p className='frs'> Our Brand </p>
                            <p className='scnd'> Find  Out More! </p>
                        </div>
                    </div>
                    <div className='boxes'>
                        <BsCalendar4Week className='ico' />
                        <div className='elemico'>
                            <p className='frs'> Return's And exchange </p>
                            <p className='scnd'> Find  Out More! </p>
                        </div>
                    </div>
                    <div className='boxes'>
                        <CiDeliveryTruck className='ico' />
                        <div className='elemico'>
                            <p className='frs'> FREE DELIVERY OVER 200 EUR </p>
                            <p className='scnd'> Find  Out More! </p>
                        </div>
                    </div>
                    <div className='boxes'>
                        <TfiHelpAlt className='ico' />
                        <div className='elemico'>
                            <p className='frs'> Need Help ? </p>
                            <p className='scnd'> Contact Us ! </p>
                        </div>
                    </div>
                </div>
            </div>
    );
}
export default Bar ;