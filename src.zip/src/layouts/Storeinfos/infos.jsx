import React from "react";
import { Link, Route, Routes } from "react-router-dom";
import "../../pages/Home/Home.css"
import { CiLocationOn } from "react-icons/ci";
import { PiMailboxThin } from "react-icons/pi";
import { PiPhoneCallThin } from "react-icons/pi";
import { CiInstagram } from "react-icons/ci";
import { CiFacebook } from "react-icons/ci";
import { RiVisaFill } from "react-icons/ri";
import { FaCcMastercard } from "react-icons/fa6";
import { SlPaypal } from "react-icons/sl";
import { FaStripe } from "react-icons/fa";
import { RiArrowDownWideLine } from "react-icons/ri";
function Infos()
{
    return (
    <div className="lal">

    <div className='lastithem'>
            <div className='boxesls'>
                <div className='inlas'>
                    <div className='upinlas'>
                        <p>STORE LOCATOR</p>
                    </div>
                    <div className='inw'>
                        <p>Find Your Nearest Store</p>
                        <CiLocationOn className='posi' />
                    </div>
                </div>
                <div className='inlas'>
                    <div className='upinlas'>
                        <p>GLOBAL BRANDS</p>
                    </div>
                    <div className='inw'>
                        <p>About Us</p>
                    </div>
                    <div className='inw'>
                        <p>Stores</p>
                    </div>
                    <div className='inw'>
                        <p>Careers</p>
                    </div>
                </div>
                <div className='inlas'>
                    <div className='upinlas'>
                        <p>MY GLOBAL BRANDS</p>
                    </div>
                    <div className='inw'>
                        <p>My Account</p>
                    </div>
                    <div className='inw'>
                        <p>Loyalty program</p>
                    </div>
                    <div className='inw'>
                        <p>General terms</p>
                    </div>
                    <div className='inw'>
                        <p>Join now</p>
                    </div>
                </div>
                <div className='inlas'>
                    <div className='upinlas'>
                        <p>SHOPPING ONLINE</p>
                    </div>
                    <div className='inw'>
                        <p>Our Terms</p>
                    </div>
                    <div className='inw'>
                        <p>Privacy Policy</p>
                    </div>
                    <div className='inw'>
                        <p>Online Dispute Resolution</p>
                    </div>
                    <div className='inw'>
                        <p>Payment Methods</p>
                    </div>
                    <div className='inw'>
                        <p>Returns & Exchange</p>
                    </div>
                    <div className='inw'>
                        <p>Delivery</p>
                    </div>
                    <div className='inw'>
                        <p>FAQ's</p>
                    </div>
                </div>
                <div className='inlas'>
                    <div className='upinlas'>
                        <p>CUSTOMER SERVICE</p>
                    </div>
                    <div className='inw'>
                        <PiMailboxThin className='pos' />
                        <p className='mail'>mmaghri@student.1337.ma</p>
                    </div>
                    <div className='inw'>
                        <PiPhoneCallThin className='pos' />
                        <p>06000000000</p>
                    </div>
                    <div className='fol'>
                        <p>Follow Us</p>
                        <div className='social'>
                            <CiInstagram className='acc' />
                            <CiFacebook className='acc' />
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div className='lastof-last'>
        <div className='frsl'>
            <SlPaypal className='cards' />
            <RiVisaFill className='cards' />
            <FaCcMastercard className='cards' />
            <FaStripe className='cards' />
        </div>
        <div className='ssl'>
            <p>© 2023 Global Brands Store. All rights reserved . Site Map</p>
        </div>
    </div>
    </div>
    );
}
export default Infos;