import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import Admin from "./pages/Admin/Admin";
import Home from "./pages/Home/Home";
import Bar from "./layouts/bar/bar";

function App() {
  return (
    <Router>
      <Routes>
        <Route exact path="/" element={<Home />} />
        <Route exact path="/Admin" element={<Admin />} />
      </Routes>
    </Router>
  );
}

export default App;
