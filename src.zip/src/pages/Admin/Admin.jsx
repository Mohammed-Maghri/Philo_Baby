import React, { useEffect } from "react";
import Navbar from '../../layouts/Navbar/Navbar';
import "./admin.css"
import { RxPerson } from "react-icons/rx";
import Bar from '../../layouts/bar/bar';
import Infos from "../../layouts/Storeinfos/infos";
import { FaSquareCheck } from "react-icons/fa6";

function Admin() {
  let click_chose ;
  let line_under;
  let under_line ;
  let other_line;
  let pannel ;
  let secpannel;
  useEffect(()=>{
    click_chose = document.getElementById('line');
    line_under = document.getElementById('ontwo');
    other_line = document.getElementById('lineelse');
    under_line = document.getElementById('under');
    pannel = document.getElementById('pannel');
    secpannel = document.getElementById('secpannel');
  
    under_line.addEventListener('mouseenter', () => (click_chose.style.borderWidth = '2px'));
    under_line.addEventListener('mouseleave', () => (click_chose.style.borderWidth ='1px'));
    line_under.addEventListener('mouseenter', () => (other_line.style.borderWidth ='2px'));
    line_under.addEventListener('mouseleave', () => (other_line.style.borderWidth ='1px'));
  }, []);
  
  function pannel_show(number)
  {
    console.log('ex');
    if (number == '1')
    {
      console.log('in');
      if (pannel.style.display != 'block')
      {
        console.log('ierern');
        secpannel.style.display = 'none'
        pannel.style.display = 'block'
        pannel.style.alignItems = 'center';
        pannel.style.justifyContent = 'center';

      }
    }
    if (number == '0')
    {
        console.log('ierern');
        secpannel.style.display = 'block'
        pannel.style.display = 'none'
    }
  }
  return (
    <div className="all">
      <Navbar/>
      <div className="both">
        <div className="box">
          <div className="boxin">
            <p>Login or Create Account</p>
          </div>
          <div className="options">
            <div onClick={() => pannel_show('1')} id="ontwo" className="two">
              <p  id="log">Login</p>
              <div id="lineelse"  className="underline"></div>
              
            </div>
            <div onClick={() => pannel_show('0')}  id="under" className="two">
              <p id="acc">Create Account</p>
              <div id="line" className="underline"></div>
            </div>
          </div>
          <div id="pannel" className="for-notopt">
            <div className="login">
              <div className="txt"> <p> EMAIL</p></div>
                <div className="forinpt"> <input className="write" type="text" placeholder="user@gmail.com"></input></div>
                <div className="underneeth"></div>
            </div>
            <div className="login">
              <div className="txt"> <p> PASSWORD </p></div>
                <div className="forinpt"> <input className="write" type="password" placeholder="Password1234"></input></div>
                <div className="underneeth"></div>
            </div>
            <div className="longcheck">
              <div className="twos">
                <input className="btch" type="checkbox"></input>
                <p>Remember Me</p>
              </div>
              <div className="twosside">
                <p>Forget Password ?</p>
              </div>
            </div>
            <div className="inptb">
              <button className="click-ithem"> <RxPerson className="info"/> Login </button>
            </div>
          </div>
          <div id="secpannel" className="for-opt">
            <div className="packs-both">
              <div className="frr">
                <div className="txt"> <p> FIRST NAME </p></div>
                <div className="forinpt"> <input className="write" type="text" placeholder="Type Name"></input></div>
                <div className="underneeth"></div>
              </div>
              <div className="frr">
                <div className="txt"> <p> LAST NAME </p></div>
                <div className="forinpt"> <input className="write" type="text" placeholder="Type Last Name"></input></div>
                <div className="underneeth"></div>
              </div>
            </div>
            <div className="packs-both">
              <div className="frr">
                <div className="txt"> <p> EMAIL </p></div>
                <div className="forinpt"> <input className="write" type="text" placeholder="Type Email"></input></div>
                <div className="underneeth"></div>
              </div>
              <div className="frr">
                <div className="txt"> <p> CONFIRM EMAIL </p></div>
                <div className="forinpt"> <input className="write" type="text" placeholder="Confirm Email"></input></div>
                <div className="underneeth"></div>
              </div>
            </div>
            <div className="packs-both">
              <div className="frr">
                <div className="txt"> <p> EMAIL </p></div>
                <div className="forinpt"> <input className="write" type="text" placeholder="Type Email"></input></div>
                <div className="underneeth"></div>
              </div>
              <div className="frr">
                <div className="txt"> <p> PASSWORD </p></div>
                <div className="forinpt"> <input className="write" type="password" placeholder="Confirm Password"></input></div>
                <div className="underneeth"></div>
              </div>
            </div>
            <div className="packs">
              <div className="long">
                <div className="txt"> <p> PHONE NUMBER</p></div>
                <div className="forinpt"> <input className="write" type="text" placeholder="Type Telephone"></input></div>
                <div className="underneeth"></div>
              </div>
            </div>
            <div className="last">
              <div className="testlast"> <p> Minimum of 8 characters, including one number, one capital letter, and one special character.</p></div>
            </div>
            <div className="terms">
              <div className="cheks">
                <input className="btch" type="checkbox"></input>
                <p className="txtch"> I have read the Terms and Conditions and I accept them.* </p>
              </div>
              <div className="cheks">
                <input className="btch" type="checkbox"></input>
                <p className="txtch"> I have read the Privacy policy and I accept it.* </p>
              </div>
              <div className="cheks">
                <input className="btch" type="checkbox"></input>
                <p className="txtch"> I confirm I am 16 years old or above. * </p>
              </div>
            </div>
        <div className="inptb">
              <button className="click-ithem"> <RxPerson className="info"/> Login </button>
              </div>
          </div>
        </div>
        <div className="betw"></div>
        <div className="box">
          <div className="boxin">
            <p>Check Order</p>
          </div>
          <div className="partit">
            <div className="fo">
              <div className="psq">
                <div className="txt"> <p> ORDER NUMBER </p></div>
                <div className="forinpt"> <input className="write" type="text" placeholder="Type Email"></input></div>
                <div className="underneeth"></div>
              </div>
              <div className="psq">
                <div className="txt"> <p> EMAIL </p></div>
                <div className="forinpt"> <input className="write" type="text" placeholder="Type Order Number"></input></div>
                <div className="underneeth"></div>
              </div>
            </div>
            <div className="fo">
            <div className="long">
                <div className="txt"> <p> ZIP code</p></div>
                <div className="forinpt"> <input className="write" type="text" placeholder="Type Zip Code"></input></div>
                <div className="underneeth"></div>
              </div>
            </div>
            <div className="inptb">
              <button className="click-ithem">Check Order Status </button>
              </div>
          </div>
        </div>
      </div>
      <Bar/>
      <Infos/>
    </div>
  );
}

export default Admin;
