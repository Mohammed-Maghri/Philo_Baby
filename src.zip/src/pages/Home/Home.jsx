
import './Home.css';
import grl from "../../assets/images/grl.jpg"
import fash from "../../assets/images/img.jpg"
import brands from "../../assets/images/pics.jpg"
import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import Navbar from '../../layouts/Navbar/Navbar';
import Bar from '../../layouts/bar/bar';
import { CiLocationOn } from "react-icons/ci";
import { PiMailboxThin } from "react-icons/pi";
import { PiPhoneCallThin } from "react-icons/pi";
import { CiInstagram } from "react-icons/ci";
import { CiFacebook } from "react-icons/ci";
import { RiVisaFill } from "react-icons/ri";
import { FaCcMastercard } from "react-icons/fa6";
import { SlPaypal } from "react-icons/sl";
import { FaStripe } from "react-icons/fa";
import { RiArrowDownWideLine } from "react-icons/ri";
import Infos from "../../layouts/Storeinfos/infos"
function Home() {

    return (
        <div className='page'>
            <Navbar />
            <div className='second-elem'>
                <div className='first-two'>
                    <div className='fr' id='for-text'>
                        <img className='boy' src={fash}></img>
                        <div className='on-it' id='tures'>
                            <div className='to'>
                                <p className='txt'>Men</p>
                            </div>
                        </div>
                    </div>
                    <div className='sec'>
                        <div className='wm'>
                            <p className='wmtxt'>Women</p>
                        </div>
                        <img className='grl' src={grl}></img>
                    </div>
                </div>
            </div>
            <Bar/>
            <div className='down-down'>
                <div className='downmail'>
                    <div className='first-box'>
                        <div className='one'>
                            <p> Subscribe Now </p>
                        </div>
                        <div className='sec-this'>
                            <p> Sign up to receive email  on the latest trends, new arrivals, exclusive offers</p>
                            <p>  special events, promotions and sale notifications. </p>
                            <p className='here'>HERE</p>
                        </div>
                        <div className='select'>
                            <div className='frbox'>
                                <input className='ck' type='checkbox'></input>
                                <p> Women</p>
                            </div>
                            <div className='frbox'>
                                <input className='ck' type='checkbox'></input>
                                <p> Men</p>
                            </div>
                            <div className='frbox'>
                                <input className='ck' type='checkbox'></input>
                                <p> Children</p>
                            </div>
                        </div>
                        <div className='under'>
                            <div className='TEXT'>
                                <div className='txtins'>
                                    <p>YOUR EMAIL ADDRESS</p>
                                </div>
                                <div className='forinp'>
                                    <input className='inpt' type='text' placeholder='Type Email'></input>
                                    <div className='divslc'></div>
                                </div>
                                <div className='secinp'>
                                    <div className='getboth'>
                                        <div className='txtboth'>
                                            <p> First Name</p>
                                        </div>
                                        <input className='inpsmal' type='text' placeholder='Type First Name'></input>
                                        <div className='line'></div>
                                    </div>
                                    <div className='getboth'>
                                        <div className='txtboth'>
                                            <p> Last Name</p>
                                        </div>
                                        <input className='inpsmal' type='text' placeholder='Type Last Name'></input>
                                        <div className='line'></div>
                                    </div>
                                </div>
                                <div className='forbut'>
                                    <button className='forb'> SUBSCRIBE </button>
                                    <p> By signing up you agree to our Terms and Conditions and our privacy policy. </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <Infos/>
        </div>
    );
}

export default Home;
