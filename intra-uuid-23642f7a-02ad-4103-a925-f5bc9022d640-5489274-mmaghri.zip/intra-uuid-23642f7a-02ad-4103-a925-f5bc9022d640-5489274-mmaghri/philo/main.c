/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mmaghri <mmaghri@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/04/21 12:08:13 by mmaghri           #+#    #+#             */
/*   Updated: 2024/05/06 13:28:22 by mmaghri          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philo.h"

void leack_detection()
{
	system("leaks philo");
}

void	increment_this(t_ini *point, int *flag, int *increment)
{
	pthread_mutex_lock(point->lock_each_time);
	if (point->each_time == point->nf_t_each_philo)
	{
		*flag += 1 ;
		*increment += 1;
	}
	pthread_mutex_unlock(point->lock_each_time);
}

int	main(int argc, char **argv)
{
	atexit(leack_detection);
	int			index;
	int			*all_of_it;
	t_ini		*waa;
	t_in_str	*this_all;

	if (argc > 6)
		return (printf("Invalid Argument !\n"), 0);
	index = 1;
	if (check_if(argv, argc) == -1)
		return (-1);
	all_of_it = return_to_array(argv);
	if (!all_of_it)
		return (0);
	this_all = malloc(sizeof(t_in_str));
	if (!this_all)
		return (-1);
	usleep(10);
	if (fill_shit(this_all, all_of_it, argc) == -1)
		return (free(this_all), free(all_of_it),-1);
	waa = start_dining(this_all);
	if (function_create_many_philos(waa, this_all) == -1)
		return (free(waa), 1);
	return (free(waa), free(this_all), 0);
}
