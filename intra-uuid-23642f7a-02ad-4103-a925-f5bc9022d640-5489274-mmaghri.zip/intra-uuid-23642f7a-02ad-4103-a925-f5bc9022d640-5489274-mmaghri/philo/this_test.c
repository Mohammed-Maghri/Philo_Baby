/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   this_test.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mmaghri <mmaghri@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/05 20:25:11 by mmaghri           #+#    #+#             */
/*   Updated: 2024/05/05 20:42:33 by mmaghri          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

# include <stdio.h>
# include <stdlib.h>
# include <unistd.h>

typedef struct this
{
    int this;
    void *next ;
} t_this;

t_this *return_new(t_this *this, int number)
{
    t_this *copy;

    copy = malloc(sizeof(t_this) + 1);
    copy->this = number ;
    copy->next = NULL;
    while (this->next)
    {
        copy->this = this->this;
        this = this->next;
        copy = copy->next ;
    }
    this->next = copy ;
    copy->next = NULL;
    return (copy);
}
int main()
{
    t_this *check ;
    check = malloc(sizeof(t_this));

    check->this = 1;
    check->next = NULL ;
    check = return_new(check, 80);

    while (check)
    {
        printf("[%d]\n", check->this);
        check = check->next;
    }
}