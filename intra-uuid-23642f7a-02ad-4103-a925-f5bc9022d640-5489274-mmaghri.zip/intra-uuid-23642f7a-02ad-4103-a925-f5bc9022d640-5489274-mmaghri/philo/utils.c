/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mmaghri <mmaghri@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/04/13 13:22:08 by mmaghri           #+#    #+#             */
/*   Updated: 2024/05/05 15:36:23 by mmaghri          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philo.h"

int	not_valid(char string, int num)
{
	if (num <= 4)
		return (-1);
	if (string >= '0' && string <= '9')
		return (0);
	if (string == '+' || string == ' ' || string == '\t')
		return (0);
	return (-1);
}

int	count_it(char *string, char carac)
{
	int	index;
	int	flag;

	flag = 0;
	index = 0;
	while (string[index])
	{
		if (string[index] == carac)
			flag++ ;
		index++ ;
	}
	if (flag > 1)
		return (-1);
	return (0);
}

int	le_count(char *string)
{
	int	index;

	index = 0;
	while (string[index])
		index++ ;
	return (index);
}

int	not_number(char string)
{
	if ((string >= '0' && string <= '9') || string == '+')
		return (0);
	return (-1);
}

int	there_is_nothing(char *string)
{
	int		index;
	int		flag;

	flag = 0;
	index = 0;
	while (string[index])
	{
		if (string[index] >= '0' || string[index] == '9')
			flag++ ;
		index++ ;
	}
	return (flag);
}
