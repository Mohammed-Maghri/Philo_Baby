/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   tch.c                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mmaghri <mmaghri@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/04/21 15:50:11 by mmaghri           #+#    #+#             */
/*   Updated: 2024/05/05 15:36:17 by mmaghri          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philo.h"

int	check_valid(char *string)
{
	return (number_converter(string));
}

int	function_add(t_ini *point, int index, int flag, int increment)
{
	while (1)
	{
		increment_this(&point[increment], &flag, &increment);
		if (increment == point[increment].nmp - 1 && point[increment].nmp != 1)
			return (pthread_mutex_lock(point->print_not), -1);
		usleep(50);
		if (index == point->nmp)
			index = 0;
		pthread_mutex_lock(point->lock_him);
		if ((fu() - point->last_meal_time) > \
		point[index].time_to_die)
		{
			function_t(point);
			f_p("died\n", point->id, (fu() - \
			point->start_time), point);
			pthread_mutex_lock(point->print_not);
			return (-1);
		}
		pthread_mutex_unlock(point->lock_him);
		index++ ;
	}
	return (0);
}

int	last_check(char string)
{
	if (string == '+')
		return (0);
	if (string >= '0' && string <= '9')
		return (0);
	return (-1);
}

int	loop_on_all(char *string, int num)
{
	int	index;

	index = 0;
	if ((le_count(string) == 1 && string[0] == '+') || \
	le_count(string) == 0 || count_it(string, '+') == -1)
		return (printf("Invalid argument !\n"), -1);
	while (string[index])
	{
		if (not_valid(string[index], num) == -1 \
		|| last_check(string[index]) == -1)
		{
			printf("Invalid argument !\n");
			return (-1);
		}
		if (string[index] == '+' && \
		not_number(string[index + 1]) == -1)
		{
			printf("Invalid argument !\n");
			return (-1);
		}
		index++ ;
	}
	return (0);
}
