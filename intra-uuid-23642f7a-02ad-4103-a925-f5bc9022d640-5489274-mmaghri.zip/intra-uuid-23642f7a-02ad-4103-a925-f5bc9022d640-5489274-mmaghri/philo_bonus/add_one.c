/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   add_one.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mmaghri <mmaghri@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/05 15:27:20 by mmaghri           #+#    #+#             */
/*   Updated: 2024/05/06 13:25:50 by mmaghri          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "phil.h"

int	loop_on_all(char *string, int num)
{
	int	index;

	index = 0;
	if ((le_count(string) == 1 && string[0] == '+') || \
	le_count(string) == 0 || count_it(string, '+') == -1)
		return (printf("Invalid argument z!\n"), -1);
	while (string[index])
	{
		if (not_valid(string[index], num) == -1 \
		|| last_check(string[index]) == -1)
		{
			printf("Invalid argument r!\n");
			return (-1);
		}
		if (string[index] == '+' && \
		not_number(string[index + 1]) == -1)
		{
			printf("Invalid argument f!\n");
			return (-1);
		}
		index++ ;
	}
	return (0);
}
