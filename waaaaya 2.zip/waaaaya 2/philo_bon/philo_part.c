/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   philo_part.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mmaghri <mmaghri@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/04/24 11:12:21 by mmaghri           #+#    #+#             */
/*   Updated: 2024/05/04 20:19:05 by mmaghri          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "phil.h"

long long	fu(void)
{
	struct timeval	this_time;

	gettimeofday(&this_time, NULL);
	return (this_time.tv_sec * 1000 + this_time.tv_usec / 1000);
}

int	phill_vars_nedded(t_not *this, int *array, int argc)
{
	if (argc - 1 == 4)
		this->each_philo = -1;
	else if (argc - 1 == 5)
		this->each_philo = array[4];
	this->number_philos = array[0];
	if (this->number_philos == 0)
		return (-1);
	this->time_die = array[1];
	this->time_eat = array[2];
	this->time_sleep = array[3];
	if (this->time_die < 60 || \
	this->time_eat < 60 || \
	this->time_sleep < 60)
	{
		usleep(10);
		printf("Not a valid argument !\n");
		return (free(this), -1);
	}
	if (this->each_philo == 0)
	{
		printf("Invalid !\n");
		return (free(this), -1);
	}
	free(this);
	return (0);
}

void	f_p(char *string, int id, long long pass, sem_t *var)
{
	sem_wait(var);
	printf("%lld %d %s", pass, id, string);
	sem_post(var);
}

void	condition(int *index, int number_philos)
{
	if (*index == number_philos - 1)
		*index = 0;
	*index += 1;
}

void	*start_philos(void *args)
{
	t_not	*copy;
	int		index;

	copy = (t_not *)args ;
	index = 0;
	while (1)
	{
		if ((fu() - copy[index].last_meal_time) > \
		copy->time_die && copy[index].last_meal_time > 0)
		{
			sem_wait(copy->print);
			printf("%lld ", (fu() - copy->start_time));
			printf("%d ", copy[index].id);
			printf("died\n");
			exit(1);
		}
		if (copy[copy->number_philos - 1].how_many_time >= \
		copy[copy->number_philos -1].each_philo && copy->each_philo != -1)
		{
			sem_wait(copy->print);
			exit(1);
		}
		condition(&index, copy->number_philos);
	}
	return (NULL);
}
