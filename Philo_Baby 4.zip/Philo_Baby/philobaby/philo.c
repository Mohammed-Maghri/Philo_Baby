/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   philo.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mmaghri <mmaghri@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/26 03:38:54 by mmaghri           #+#    #+#             */
/*   Updated: 2024/04/19 13:25:59 by mmaghri          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philo.h"

int check_if(char **all_this, int argc)
{
    int index;

    index = 1;
    while (all_this[index])
    {
        if (loop_on_all(all_this[index], argc) == -1)
            return (-1);
        index++;
    }
    return (0);
}
int *return_to_array(char **argv)
{
    int index;
    int *this_array;
    int increment;

    increment = 0;
    this_array = malloc(sizeof(int) * 5);
    if (!this_array)
        return (NULL);
    index = 1;
    while (argv[index])
    {
        if (number_converter(argv[index]) == -1)
        {
            printf("Invalid argument !\n");
            return (NULL);
        }
        this_array[increment] = check_valid(argv[index]);
        increment++;
        index++;
    }
    return (this_array);
}

int fill_shit(in_str *this, int *array, int argc)
{
    (void)this;
    (void)array;
    int index;

    index = 0;
    if (argc - 1 == 4)
        this->nf_t_each_philo = -1;
    else if (argc - 1 == 5)
        this->nf_t_each_philo = array[4];
    this->number_of_philosophers = array[0];
    this->time_to_die = array[1];
    this->time_to_eat = array[2];
    this->time_to_sleep = array[3];
    if (this->nf_t_each_philo == 0)
    {
        printf("Not Enough !\n");
        return (-1);
    }
    index = 0;
    while (index < this->number_of_philosophers)
    {
        pthread_mutex_init(&this->lock_var[index], NULL);
        index++;
    }
    pthread_mutex_init(&this->print_not, NULL);
    pthread_mutex_init(&this->monitor, NULL);
    pthread_mutex_init(&this->only_one, NULL);
    pthread_mutex_init(&this->stop, NULL);
    return (0);
}

t_ini *start_dining(in_str *this)
{
    t_this wee;

    wee.index = 0;
    t_ini *copy;
    copy = malloc(sizeof(t_ini) * this->number_of_philosophers);
    while (wee.index < this->number_of_philosophers)
    {
        copy[wee.index].id = wee.index + 1;
        copy[wee.index].whole_philos = this->number_of_philosophers;
        if (copy[wee.index].id % 2 != 0)
        {
            copy[wee.index].left_one = (wee.index + 1) % this->number_of_philosophers;
            copy[wee.index].right_one = wee.index;
        }
        else if (copy[wee.index].id % 2 == 0)
        {
            copy[wee.index].right_one = (wee.index + 1) % this->number_of_philosophers;
            copy[wee.index].left_one = wee.index;
        }
        copy[wee.index].lock_var = &this->lock_var[copy[wee.index].left_one];
        copy[wee.index].sec_var = &this->lock_var[copy[wee.index].right_one];
        copy[wee.index].time_to_sleep = this->time_to_sleep;
        copy[wee.index].print_not = &this->print_not;
        copy[wee.index].time_to_eat = this->time_to_eat;
        copy[wee.index].time_to_die = this->time_to_die;
        copy[wee.index].onlyone = &this->only_one;
        copy[wee.index].stop = &this->stop;
        copy[wee.index].number_of_philosophers = this->number_of_philosophers;
        copy[wee.index].start_time = function_count_mils();
        wee.index++;
    }
    wee.index = 0;
    return (copy);
}

long long function_count_mils()
{
    struct timeval this_time;

    gettimeofday(&this_time, NULL);
    return (this_time.tv_sec * 1000 + this_time.tv_usec / 1000);
}

void function_print(char *string, t_ini *waa, long long pass)
{
    pthread_mutex_lock(waa->print_not);
    if (pass > -1)
        printf("%lld ", pass);
    if (string)
        printf("%s", string);
    pthread_mutex_unlock(waa->print_not);
}

void function_p(char *string, int id, long long pass, t_ini *waa)
{
    pthread_mutex_lock(waa->print_not);
    printf("%lld %d %s", pass, id, string);
    pthread_mutex_unlock(waa->print_not);
}

void *check_one_them(void *arg)
{
    t_ini *waa;

    waa = (t_ini *)arg;

    int index ;
    index = 0;
    while (1)
    {
        usleep(50);
        if (index ==  waa->number_of_philosophers)
            index = 0;
        function_p("-->Philo\n", index, waa->last_meal_time, waa);
        printf("((%d))\n", index);
        if ((function_count_mils() - waa->last_meal_time) > waa[index].time_to_die)
        {
            function_p("-->\n", index, waa->last_meal_time, waa);
            function_t(waa);
            break;
        }
        index++ ;
    }
    return (NULL);
}

void function_t(t_ini *waa)
{
    pthread_mutex_lock(waa->stop);
    waa->lock_time = 1;
    waa->time = -1;
    pthread_mutex_unlock(waa->stop);
}
void *start_philos(void *args)
{
    t_ini *waa;
    int index;
    int i;

    index = 0;
    waa = (t_ini *)args;

    i = 0;
    if (waa->id % 2 == 0)
        usleep(500);
    i = function_count_mils();
    while (1)
    {
        pthread_mutex_lock(waa->lock_var);
        function_p("has taken a fork\n", waa->id, (function_count_mils() - waa->start_time), waa);
        pthread_mutex_lock(waa->sec_var);
        function_p("has taken a fork\n", waa->id, (function_count_mils() - waa->start_time), waa);
        waa->last_meal_time = function_count_mils();
        function_p("is eating\n", waa->id, (function_count_mils() - waa->start_time), waa);
        function_sleep(waa->time_to_eat);
        pthread_mutex_unlock(waa->lock_var);
        pthread_mutex_unlock(waa->sec_var);
        function_p("is sleeping\n", waa->id, (function_count_mils() - waa->start_time), waa);
        function_sleep(waa->time_to_sleep);
        pthread_mutex_lock(waa->stop);
        pthread_mutex_unlock(waa->stop);
    }
    return (NULL);
}

void function_sleep(long long in_milisecond)
{
    (void)in_milisecond;
    long long start;

    start = function_count_mils();
    while (function_count_mils() - start < in_milisecond)
        usleep(50);
}

void function_create_many_philos(t_ini *point, in_str *more)
{
    pthread_t this_thread;

    int index;

    index = 0;
    while (index < more->number_of_philosophers)
    {
        pthread_create(&this_thread, NULL, &start_philos, &point[index]);
        pthread_detach(this_thread);
        index++;
    }
    index = 0;
    while (1)
    {
        usleep(50);
        if (index ==  point->number_of_philosophers)
            index = 0;
        if ((function_count_mils() - point->last_meal_time) > point[index].time_to_die)
        {
            function_t(point);
            function_p("died\n", point->id, (function_count_mils() - point->start_time), point);
            pthread_mutex_lock(point->print_not);
            index = -1;
            break;
        }
        index++ ;
    }
    if (index == -1)
        return ;
}

int main(int argc, char **argv)
{
    if (argc > 6)
    {
        printf("Invalid Argument !\n");
        return (0);
    }
    int index;
    int *all_of_it;
    t_ini *waa;

    index = 1;
    if (check_if(argv, argc) == -1)
        return (-1);
    all_of_it = return_to_array(argv);
    if (!all_of_it)
        return (0);
    in_str *this_all;
    this_all = malloc(sizeof(in_str));
    if (fill_shit(this_all, all_of_it, argc) == -1)
        return (-1);
    waa = start_dining(this_all);
    function_create_many_philos(waa, this_all);
    return (0);
}