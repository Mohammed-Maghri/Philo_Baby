#ifndef PHILO_H
# define PHILO_H

#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <time.h>
#include <unistd.h>
#include <sys/time.h>

typedef struct this_str {
    int index;
    int minis;
    long long store;
} t_this ;

typedef struct initailize_philo {
    long long last_meal_time;
    int id;
    int left_one;
    int right_one;
    int whole_philos;
    int time_to_sleep;
    int time_to_eat;
    int time_to_die;
    int if_dead;
    int number_of_philosophers;
    pthread_mutex_t *sec_var;
    pthread_mutex_t *lock_var;
    pthread_mutex_t *print_not;
    pthread_mutex_t *onlyone;
    pthread_mutex_t *stop;
    int time;
    int lock_time;
    long long  start_time;
} t_ini ;

typedef struct in_stru {
    int nf_t_each_philo;
    int number_of_philosophers;
    int time_to_die;
    int time_to_eat;
    int time_to_sleep;
    t_ini   *philo;
    pthread_mutex_t stop;
    pthread_mutex_t print_not;
    pthread_mutex_t monitor;
    pthread_mutex_t lock_var[200];
    pthread_mutex_t only_one;
} in_str ;

void function_t(t_ini *waa);
int     le_count(char *string);
long long function_count_mils();
int     number_converter(char *string);
void*   thread_function(void* arg);
int     not_valid(char string, int num);
int     loop_on_all(char *string, int num);
int     check_valid(char *string);
void    function_sleep(long long in_milisecond);

#endif