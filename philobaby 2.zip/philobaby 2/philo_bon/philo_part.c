/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   philo_part.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mmaghri <mmaghri@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/04/24 11:12:21 by mmaghri           #+#    #+#             */
/*   Updated: 2024/05/02 18:32:31 by mmaghri          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "phil.h"
long long	fu(void)
{
	struct timeval	this_time;

	gettimeofday(&this_time, NULL);
	return (this_time.tv_sec * 1000 + this_time.tv_usec / 1000);
}

void phill_vars_nedded(t_not *phill, int *array)
{
    phill->number_philos = array[0];
    phill->time_die = array[1];
    phill->time_sleep = array[3];
    phill->time_eat = array[2];
    if (phill->time_eat < 60 || phill->time_die < 60 || phill->time_sleep < 60)
        {
            printf("Invalid Argument !\n");
            exit(1);
        }
    if (array[4] == 0)
        phill->each_philo = -1;
    else
        phill->each_philo = array[4];
}

void	f_p(char *string, int id, long long pass, sem_t *var)
{
    sem_wait(var);
	printf("%lld %d %s", pass, id, string);
    sem_post(var);
}

void *start_philos(void *args)
{
    t_not *copy;
    copy = (t_not*)args;
    int index;

    index = 0;
    while (1)
    {
        if ((fu() - copy[index].last_meal_time) > copy->time_die && copy[index].last_meal_time > 0)
        {
            sem_wait(copy->print);
            printf("%lld ", (fu() - copy->start_time));
            printf("%d ", copy[index].id);
            printf("died\n");
            exit(1);
        }
        if (copy[copy->number_philos - 1].how_many_time >= copy[copy->number_philos -1].each_philo)
        {
            sem_wait(copy->print);
            exit(1);
        }
        if (index == copy->number_philos - 1)
            index = 0;
        index++ ;
    }
    return (NULL);
}

t_not   *return_number_philo(t_not *check)
{
    int		index;
	t_not	*this = malloc(sizeof(t_not) * check->number_philos);

	index = 0;
    this->index = 0;
    while (index < check->number_philos)
    {
		this[index].number_philos = check->number_philos ;
		this[index].each_philo = check->each_philo ;
		this[index].time_die = check->time_die ;
		this[index].time_eat = check->time_eat ;
		this[index].time_sleep = check->time_sleep ;
		this[index].how_many_time = check->how_many_time ;
		this[index].last_meal_time = 0;
		this[index].id = index ;
		this[index].outside = 0;
		index++ ;
    }
	return (this);
}

void	function_sleep(long long in_milisecond)
{
	long long		start;

	(void)in_milisecond;
	start = fu();
	while (fu() - start < in_milisecond)
		usleep(50);
}

int     make_bonus(t_this *varible, t_not *check)
{
    (void)varible ;
    
    int index;
    pid_t pid;

    pid = -1;
    index = 0;
	t_not *copy;
    int *value ;
    int flag;
    int x;

    x = 0;
    flag = 0;
    index = 0;
    value = &index;
	copy = return_number_philo(check);
    sem_unlink("protec");
    sem_unlink("print");
    copy->var = sem_open("protec", O_CREAT | O_EXCL, 644, check->number_philos);
    copy->print = sem_open("print", O_CREAT, 644 , 1);
    copy->start_time = fu();
    copy->last_meal_time = fu();
    copy->number_philos =  check->number_philos ;
    while (index < check->number_philos)
    {
        pid = fork();
        copy->porcess[index] = pid; 
        if (pid == 0)
        {
            pthread_create(&copy->initial, NULL, &start_philos, copy);
            pthread_detach(copy->initial);
            while (1)
            {
                sem_wait(copy->var);
                f_p("has taken a fork\n", copy[index].id, (fu() - copy->start_time), copy->print);
                copy[index].last_meal_time = fu();
                sem_wait(copy->var);
                copy[index].how_many_time++ ;
                f_p("has taken a fork\n", copy[index].id, (fu() - copy->start_time), copy->print);
                f_p("is eating\n", copy[index].id, (fu() - copy->start_time), copy->print);
                function_sleep(copy->time_eat);
                sem_post(copy->var);
                sem_post(copy->var);
                f_p("is sleeping\n", copy[index].id, (fu() - copy->start_time), copy->print);
                function_sleep(copy->time_sleep);
                f_p("is thinking\n", copy[index].id, (fu() - copy->start_time), copy->print);
            }
        }
        index++;
    }
    waitpid(-1, &x, 0);
    index = 0;
    while (index < check->number_philos)
    {
        kill(copy->porcess[index], SIGILL);
        index++ ;
    }
    return (-1);
}
