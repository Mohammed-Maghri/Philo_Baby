/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   garbege_collecer.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mmaghri <mmaghri@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/02 11:08:50 by mmaghri           #+#    #+#             */
/*   Updated: 2024/05/02 11:32:52 by mmaghri          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

# include <stdio.h>
# include <stdlib.h>
# include <string.h>
# include <unistd.h>
# include <semaphore.h>
# include <pthread.h>
# include <sys/time.h>
# include <fcntl.h>

typedef struct gc
{
    void    *head;
    
} t_gc;

int loop_on_array(void **array)
{
	int index;

	index = 0;

	if (!array)
		return (0);
	while (array[index])
		index++ ;
	return (index);
}
void *garbeg_collector(void *adress, int flag, int size)
{
    void	**array;
    void	*adre;
    int     index;

	index = 1;
	adre = malloc(sizeof(void *) + loop_on_array(array) + size);
	array[0] = adress ;
	while (array[index])
		index++ ;
	array[index] = adress ;
	index++ ;
    array[index] = NULL;
    return (adress);
}
int main()
{
    char *mlloc_test = garbeg_collector(malloc(sizeof(char *) + 10), 1, 10);

    mlloc_test = "waaaaaaay";

    while (1)
    {
        printf("%s\n", mlloc_test);
        usleep(5000);
    }
}