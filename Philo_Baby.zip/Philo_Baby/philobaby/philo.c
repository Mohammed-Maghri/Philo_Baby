/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   philo.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mmaghri <mmaghri@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/26 03:38:54 by mmaghri           #+#    #+#             */
/*   Updated: 2024/04/15 18:47:58 by mmaghri          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philo.h"

int check_if(char **all_this, int argc)
{
    int index;

    index = 1;
    while (all_this[index])
    {
        if (loop_on_all(all_this[index], argc) == -1)
            return (-1);
        index++ ;
    }
    return (0);
}
int *return_to_array(char **argv)
{
    int     index;
    int    *this_array;
    int     increment;

    increment = 0;
    this_array = malloc(sizeof(int) * 5);
    if (!this_array)
        return (NULL);
    index = 1;
    while (argv[index])
    {
        if (number_converter(argv[index]) == -1)
        {
            printf("Invalid argument !\n");
            return (NULL);
        }
        this_array[increment] = check_valid(argv[index]);
        increment++ ;
        index++ ;
    }
    return (this_array);
}

int fill_shit(in_str *this, int *array, int argc)
{
    (void)this;
    (void)array;
    int index ;

    index = 0;
    if (argc - 1  == 4)
        this->nf_t_each_philo = -1;
    else if (argc -1 == 5)
        this->nf_t_each_philo = array[4];
    this->number_of_philosophers = array[0];
    this->time_to_die = array[1];
    this->time_to_eat = array[2];
    this->time_to_sleep = array[3];
    if (this->nf_t_each_philo == 0)
    {
        printf("Not Enough !\n");
        return(-1);
    }
    index = 0;
    while (index < this->number_of_philosophers)
    {
        pthread_mutex_init(&this->lock_var[index], NULL);
        index++ ;
    }
    pthread_mutex_init(&this->print_not, NULL);
    return (0);
}

t_ini *start_dining(in_str *this)
{
    t_this wee;

    wee.index = 0;
    t_ini *copy;
    
    copy = malloc(sizeof(t_ini) * this->number_of_philosophers);
    while (wee.index < this->number_of_philosophers)
    {
        copy[wee.index].id = wee.index + 1;
        copy[wee.index].whole_philos = this->number_of_philosophers;
        copy[wee.index].left_one = wee.index;
        copy[wee.index].right_one = (wee.index + 1) % this->number_of_philosophers;
        copy[wee.index].lock_var = &this->lock_var[copy[wee.index].left_one];
        copy[wee.index].sec_var = &this->lock_var[copy[wee.index].right_one];
        copy[wee.index].time_to_sleep = this->time_to_sleep ;
        copy[wee.index].print_not = &this->print_not;
        copy[wee.index].time_to_eat = this->time_to_eat ;
        wee.index++ ;
    }
    wee.index = 0;
    return (copy);
}

long long function_count_mils()
{
    struct timeval this_time;
    long long totaltime;
    int time;

    time = gettimeofday(&this_time, NULL);
    totaltime = this_time.tv_sec * 1000 + this_time.tv_usec / 1000;
    return (totaltime);
}

void function_print(char *string, t_ini *waa, long long pass)
{
    pthread_mutex_lock(waa->print_not);
    if (pass > -1)
    {
        printf("%lld ", pass);
    }
    if (string)
    {
        printf("%s", string);
    }
    pthread_mutex_unlock(waa->print_not);
}
void *start_philos(void *args)
{
    t_ini *waa;
    int index;
    long long time ;

    time = function_count_mils();
    index = 0;
    waa = (t_ini *)args ;
    if (waa->id % 2 == 0)
        function_sleep(waa->time_to_eat * 1000 / 2);
    while (1)
    {
        pthread_mutex_lock(waa->lock_var);
        function_print("X", waa, function_count_mils() - time);
        function_print("->", waa, waa->id);
        function_print("Grab Fork \n", waa, -1);
        pthread_mutex_lock(waa->sec_var);
        function_print("X", waa, function_count_mils() - time);
        function_print("->", waa, waa->id);
        function_print("Grab second Fork \n", waa, -1);
        function_sleep(waa->time_to_eat * 1000);
        pthread_mutex_unlock(waa->lock_var);
        pthread_mutex_unlock(waa->sec_var);

    }
    return (NULL);
}

void function_sleep(long long in_milisecond)
{
    (void)in_milisecond ;
    long long start;

    start = function_count_mils();
    while (function_count_mils() - start < in_milisecond)
        usleep(500);
}

void function_create_many_philos(t_ini *point, in_str *more)
{
    pthread_t this_thread;
    int index;

    index = 0;
    while (index < more->number_of_philosophers)
    {
        pthread_create(&this_thread, NULL, &start_philos, &point[index]);
        index++;
    }
    index = 0;
    while (index < more->number_of_philosophers)
    {
        pthread_join(this_thread, NULL);
        index++;
    }
    sleep(1);
}

int main(int argc, char **argv)
{
    if (argc > 6)
    {
        printf("Invalid Argument !\n");
        return (0);
    }
    int index ;
    int *all_of_it;
    t_ini *waa;

    index = 1;
    if (check_if(argv, argc) == -1)
        return (-1);
    all_of_it = return_to_array(argv);
    if (!all_of_it)
        return (0);
    in_str  *this_all;
    this_all = malloc(sizeof(in_str));
    if (fill_shit(this_all , all_of_it, argc) == -1)
        return (-1);
    waa = start_dining(this_all);
    function_create_many_philos(waa, this_all);
    printf("-----------------****----------------\n");
    return 0;
}


// Meal 1 : 4 eggs one avocado one tomato in approximately 542 calories 32 grams of protein in total 
//     Eggs: 280 calories 24-28 grams Protein
//     Avocado: 240 calories 3 grams Protein 
//     Tomato: 22 calories  1 gram Protein

// Meal 2 : Chicken Breast Rice Sweet Potato in approximately 812 calories  132 grams of protein in total 
//     Chicken Breast: Approximately 125-137.5 grams protein
//     Rice: Approximately 2-3 grams protein
//     Sweet Potato: Approximately 2-3 grams protein

// Meal 3 : 100 grams of oats, 1 medium-sized banana, and 1 cup of milk
//     100g oats : Approximately 389 calories 16.9 grams Protein
//     Banana : Approximately 89 cal 2g Protein
//     Milk: Approximately 103-150 calories  8-8.7 grams Protein

// Meal 4 : 100 grams of oats, 1 medium-sized banana, and 1 cup of milk
//     100g oats : Approximately 389 calories 16.9 grams Protein
//     Banana : Approximately 89 cal 2g Protein
//     Milk: Approximately 103-150 calories  8-8.7 grams Protein
